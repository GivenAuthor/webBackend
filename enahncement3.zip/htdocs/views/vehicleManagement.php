<?php
require_once $_SERVER['DOCUMENT_ROOT'] .'./index.php';
require_once($_SERVER['DOCUMENT_ROOT'] .'./library/connections.php');
require_once($_SERVER['DOCUMENT_ROOT'] .'./model/mainModel.php');
?>
<div class="content-wrapper">
<header>
    <div class="top-banner">
        <img src="../images/site/logo.png" alt="Technically this shouldn't need an alt since it's purely decorative">
        <!-- <a href="./views/login.php" title="My Account">My Account</a> -->
        <a href="../controllers/accountController.php?action=login" title="My Account">My Account</a>
    </div>
    <nav>
        <?php echo getNavList(); ?>
    </nav>
</header>

<?php
echo '<a href="./addClassification.php">Add Classification</a>
        <br>
        <a href="./addVehicle.php">Add Vehicle</a>';
?>

<footer>
    <p>&copy; PHP Motors, All rights reserved.</p>
    <p>All Images are believed to be in "Fair Use". Please notify the author if any are not &amp; they will be removed.</p>
    <p>Last updated Jan. 2022</p>
</footer>
</div>