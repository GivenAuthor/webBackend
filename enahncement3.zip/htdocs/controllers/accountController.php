<?php

    $action = filter_input(INPUT_POST, 'action');
        if ($action == NULL) {
    $action = filter_input(INPUT_GET, 'action');
    switch ($action){
        case 'login':
            include $_SERVER['DOCUMENT_ROOT'] .'./views/login.php';
        break;
        case 'register':
            include $_SERVER['DOCUMENT_ROOT'] .'./views/register.php';
        default:
            include $_SERVER['DOCUMENT_ROOT'] .'./views/login.php';
       }
    }

?>