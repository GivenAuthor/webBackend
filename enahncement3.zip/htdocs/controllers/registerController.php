<?php 
include_once('../models/accountsModel.php');

function registerUser() {
    
    $email = filter_input(INPUT_POST, 'email');
    $fname = filter_input(INPUT_POST, 'fname');
    $lname = filter_input(INPUT_POST, 'lname');
    $password = filter_input(INPUT_POST, 'password');
}

?>