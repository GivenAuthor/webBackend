<?php
include_once('../models/main-model.php');
include_once('../models/vehicleModel.php');


$classifications = getClassifications();

// nav list form will need an action value
$navList = '<form method="post" action="">:<ul>';
$navList .= "<li><a href='./index.php' title='View the PHP Motors home page'>Home</a></li>";
foreach ($classifications as $classification) {
    $navList .= "<li><a href='./index.php?action=".urlencode($classification['classificationName'])."' title='View our $classification[classificationName] product line'>$classification[classificationName]</a></li>";
}

$navList .= '</ul></form>';

function redirect() {
    switch($_POST) {
        case "vehicle":
            header("Location: ../views/addVehicle.php");
            break;
        case "classification":
            header("Location: ../views/addClassification.php");
            break;
        default:
            header("Location: ../views/vehicleManagement.php");
            break;
    }
}

?>