<?php
include_once('../controllers/connect.php');
include_once('./classification.php');

class vehicle extends classification {

    private $vehicleId;
    private $vehicleMake;
    private $vehicleModel;
    private $vehicleDescription;
    private $vehicleImage;
    private $vehiclePrice;
    private $vehicleStock;
    private $vehicleColor;
    private $classificationType;

    public function getVehicleId() {return $this->vehicleId;}
    public function getVehicleMake() {return $this->vehicleMake;}
    public function getVehicleModel() {return $this->vehicleModel;}
    public function getVehicleDescription() {return $this->vehicleDescription;}
    public function getVehicleImage() {return $this->vehicleImage;}
    public function getVehiclePrice() {return $this->vehiclePrice;}
    public function getVehicleStock() {return $this->vehicleStock;}
    public function getVehicleColor() {return $this->vehicleColor;}
    public function getClassificationType() {return $this->getClassificationType;}

    public function setVehicleId($vehicleId) {$this->vehicleId;}
    public function setVehicleMake($vehicleMake) {$this->vehicleMake = $vehicleMake;}
    public function setVehicleModel($vehicleModel) {$this->vehicleModel = $vehicleModel;}
    public function setVehicleDescription($vehicleDescription) {$this->vehicleDescription = $vehicleDescription;}
    public function setvehicleImage($vehicleImage) {$this->vehicleImage = $vehicleImage;}
    public function setvehiclePrice($vehiclePrice) {$this->vehiclePrice = $vehiclePrice;}
    public function setVehicleStock($vehicleStock) {$this->vehicleStock = $vehicleStock;}
    public function setVehicleColor($vehicleColor) {$this->vehicleColor = $vehicleColor;}
    public function setClassificationType($classificationType) {$this->classificationType = $classificationType;}

    public function addVehicle() {
        $sql = 'INSERT INTO inventory
                    VALUES(:invMake, :invModel, :invDescription, :invImage,
                            :invThumbnail, :invPrice, :invStock, :invColor,
                            :classificationType)';
    }

    public function updateVehicle() {
        $sql = 'UPDATE inventory
                    SET';
    }

    public function deleteVehicle() {
        $sql = 'DELETE FROM inventory
                    WHERE';
    }

}

?>