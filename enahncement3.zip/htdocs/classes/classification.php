<?php
include_once('../controllers/connect.php');

class classification {

    private $classificationName;
    private $classificationId;

    public function getClassificationName() {return $this->classificationName;}
    public function getClassificationId() {return $this->classificationId;}

    public function setClassificationName($name) {$this->classificationName = $name;}
    public function setClassificationId($id) {$this->classificationId = $id;}

    public function updateClassification() {
        $sql = 'UPDATE carclassification
                SET classificationName = :classificationName
                WHERE classificationId = :classificationId';
        $stmt = $db->prepare($sql);
        $stmt->bindValue(':classificationName', $this->classificationName, PDO::PARAM_STR);
        $stmt->bindValue(':classificationId', $this->classificationId, PDO::PARAM_STR);
        $stmt->execute();
        $rowCount = $stmt->rowCount();
        $stmt->closeCursor();

        return $rowCount;
    }

    public function addClassification() {
        $db = dbConnect();
        $sql = 'INSERT INTO carclassification
                VALUES(:classificationName)';
        $stmt = $db->prepare($sql);
        $stmt->bindValue(':classificationName', $this->classificationName, PDO::PARAM_STR);
        $stmt->execute();
        $rowCount = $stmt->rowCount();
        $stmt->closeCursor();
        
        return $rowCount;
    }

    public function deleteClassification() {
        return false;
    }
}

?>