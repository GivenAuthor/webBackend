<?php
include_once('../controllers/connect.php');

$myVehicle = new vechicle;

$sqlServer = dbConnect();

function addClassification() {
    $statement = $sqlServer->prepare('INSERT INTO 
            classifications VALUES(:name)');
    
    $statement->execute(['name' => $name]);
}

// double chek the sqlServer columns on this one
function addVehicle() {
    $statement = $sqlServer->prepare('INSERT INTO 
            inventory VALUES(:vehicleName)');
    
    $statement->execute(['vehicleName' => $_POST['vehicleName']]);
}

?>