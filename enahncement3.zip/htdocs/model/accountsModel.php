<?php

public function authenticateUser() {
    $db = dbConnect();
    $sql = 'SELECT clientId FROM clients
                WHERE clientEmail = :clientEmail
                AND clientPassword = :clientPassword;';
    $stmt = $db->prepare($sql);
    $stmt->bindValue(':clientEmaile', $_POST['email'], PDO::PARAM_STR);
    $stmt->bindValue(':clientPassword', $_POST['password'], PDO::PARAM_STR);
    $stmt->execute();
    $id = $stmt->fetch();
    $stmt->closeCursor();
    if isset($id) {
        $_SESSION['email'] = $_POST['email'];
        return true;
    } else {
        return false;
    }
}

public function registerUser() {
    $db = dbConnect();
    $sql = 'INSERT INTO clients (clientFirstname, clientLastname,clientEmail, clientPassword)
        VALUES (:clientFirstname, :clientLastname, :clientEmail, :clientPassword)';
    $stmt = $db->prepare($sql);
    $stmt->bindValue(':clientFirstname', $_POST['fName'], PDO::PARAM_STR);
    $stmt->bindValue(':clientLastname', $_POST['lName'], PDO::PARAM_STR);
    $stmt->bindValue(':clientEmail', $_POST['email'], PDO::PARAM_STR);
    $stmt->bindValue(':clientPassword', $_POST['password'], PDO::PARAM_STR);
    $stmt->execute();
    $rowsChanged = $stmt->rowCount();
    $stmt->closeCursor();
    
    return $rowsChanged;
   }

?>