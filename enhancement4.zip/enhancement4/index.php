<?php
session_start();
require_once($_SERVER['DOCUMENT_ROOT'] .'./library/connections.php');
require_once($_SERVER['DOCUMENT_ROOT'] .'./model/mainModel.php');
error_reporting(-1);
ini_set('display_errors', 'true');

function getNavList() {

$classifications = getClassifications();

$navList = "<a href='./index.php' title='View the PHP Motors home page'>Home</a>";

foreach ($classifications as $classification) {
    $navList .= "<a href='./index.php?action=".urlencode($classification['classificationName'])."' title='View our $classification[classificationName] product line'>$classification[classificationName]</a>";
  }

  return $navList;
}

$action = filter_input(INPUT_POST, 'action');
if ($action == NULL) {
  $action = filter_input(INPUT_GET, 'action');
}

switch ($action){
  case 'Classic':
    //include $_SERVER['DOCUMENT_ROOT'] .'./view/classic.php';
   break;
  case '500':
    include $_SERVER['DOCUMENT_ROOT'] .'./view/500.php';
    break;
  default:
    include $_SERVER['DOCUMENT_ROOT'] .'./view/home.php';
    break;
 }

?>