<?php
require_once $_SERVER['DOCUMENT_ROOT'] .'./accounts/index.php';
require_once($_SERVER['DOCUMENT_ROOT'] .'./library/connections.php');
require_once($_SERVER['DOCUMENT_ROOT'] .'./model/mainModel.php');
?>

<header>
    <div class="top-banner">
        <img src="../images/site/logo.png" alt="Technically this shouldn't need an alt since it's purely decorative">
        <!-- <a href="./view/login.php" title="My Account">My Account</a> -->
        <a href="./controllers/accountController.php?action=login" title="My Account">My Account</a>
    </div>
    <nav>
        <?php echo getNavList(); ?>
    </nav>
</header>