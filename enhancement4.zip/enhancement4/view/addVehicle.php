<?php
include_once($_SERVER['DOCUMENT_ROOT'] .'../model/vehiclesModel.php');
include_once($_SERVER['DOCUMENT_ROOT'] .'./library/connections.php');
include_once($_SERVER['DOCUMENT_ROOT'] .'./model/mainModel.php');
?>

<div class="content-wrapper">
<head>
<link rel="stylesheet" media="screen" href="../css/template.css"/>
    <link rel="stylesheet" media="screen" href="../css/header.css"/>
    <link rel="stylesheet" media="screen" href="../css/home.css"/>
    <link rel="stylesheet" media="screen" href="../css/footer.css"/>
    <meta name="viewport" content="width=700, initial-scale=1">
    </head>
<header>
    <div class="top-banner">
        <img src="../images/site/logo.png" alt="Technically this shouldn't need an alt since it's purely decorative">
        <!-- <a href="./view/login.php" title="My Account">My Account</a> -->
        <a href="../controllers/accountController.php?action=login" title="My Account">My Account</a>
    </div>
    <nav>
        <?php echo getNavList(); ?>
    </nav>
</header>
<?php


echo '<h2>Add Vehicle</h2>
        <form method="POST" action="../vehicles/vehicleController.php?action=vehicle">
            <label for="invMake">Make: </label>
            <input type="text" name="invMake" required>
            <br>
            <label for="invModel">Model: </label>
            <input type="text" name="invModel" required>
            <br>
            <label for="invDescription">Description: </label>
            <input type="text" name="invDescription" required>
            <br>
            <label for="invImage">Image: </label>
            <input type="text" name="invImage" required>
            <br>
            <label for="invThumbnail">Thumbnail: </label>
            <input type="text" name="invThumbnail" required>
            <br>
            <label for="invPrice">Price: </label>
            <input type="text" name="invPrice" required>
            <br>
            <label for="invStock">Stock: </label>
            <input type="text" name="invStock" required>
            <br>
            <label for="invColor">Color: </label>
            <input type="text" name="invColor" required>
            <br>
            <label for="classification">Classification: </label>
            <select name="classificationId">';
            displayClassifications();
            echo
            '</select>
            <br>
            <button type="submit">Add Vehicle</button>
        </form>';

if (isset($message)) {
    echo $message;
}

?>

<footer>
    <p>&copy; PHP Motors, All rights reserved.</p>
    <p>All Images are believed to be in "Fair Use". Please notify the author if any are not &amp; they will be removed.</p>
    <p>Last updated Jan. 2022</p>
</footer>

</div>