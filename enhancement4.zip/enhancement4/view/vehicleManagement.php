<?php
include_once ($_SERVER['DOCUMENT_ROOT'] .'./vehicles/vehicleController.php');
include_once($_SERVER['DOCUMENT_ROOT'] .'./library/connections.php');
include_once($_SERVER['DOCUMENT_ROOT'] .'./model/mainModel.php');
?>
<head>
<link rel="stylesheet" media="screen" href="../css/template.css"/>
    <link rel="stylesheet" media="screen" href="../css/header.css"/>
    <link rel="stylesheet" media="screen" href="../css/home.css"/>
    <link rel="stylesheet" media="screen" href="../css/footer.css"/>
    <meta name="viewport" content="width=700, initial-scale=1">
    </head>
<div class="content-wrapper">
<header>
    <div class="top-banner">
        <img src="../images/site/logo.png" alt="Technically this shouldn't need an alt since it's purely decorative">
        <!-- <a href="./view/login.php" title="My Account">My Account</a> -->
        <a href="../controllers/accountController.php?action=login" title="My Account">My Account</a>
    </div>
    <nav>
        <?php echo getNavList(); ?>
    </nav>
</header>

<?php
echo '  <br>
        <a href="../vehicles/vehicleController.php?action=classification">Add Classification</a>
        <br>
        <a href="../vehicles/vehicleController.php?action=vehicle">Add Vehicle</a>';
?>

<footer>
    <p>&copy; PHP Motors, All rights reserved.</p>
    <p>All Images are believed to be in "Fair Use". Please notify the author if any are not &amp; they will be removed.</p>
    <p>Last updated Jan. 2022</p>
</footer>
</div>