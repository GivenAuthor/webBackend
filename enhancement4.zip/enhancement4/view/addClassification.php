<?php
include_once($_SERVER['DOCUMENT_ROOT'] .'./model/vehiclesModel.php');
require_once($_SERVER['DOCUMENT_ROOT'] .'./library/connections.php');
require_once($_SERVER['DOCUMENT_ROOT'] .'./model/mainModel.php');
include_once ($_SERVER['DOCUMENT_ROOT'] .'./vehicles/vehicleController.php');

?>
<head>
<link rel="stylesheet" media="screen" href="../css/template.css"/>
    <link rel="stylesheet" media="screen" href="../css/header.css"/>
    <link rel="stylesheet" media="screen" href="../css/home.css"/>
    <link rel="stylesheet" media="screen" href="../css/footer.css"/>
    <meta name="viewport" content="width=700, initial-scale=1">
    </head>
<div class="content-wrapper">
<header>
    <div class="top-banner">
        <img src="../images/site/logo.png" alt="Technically this shouldn't need an alt since it's purely decorative">
        <!-- <a href=".//login.php" title="My Account">My Account</a> -->
        <a href="../controllers/accountController.php?action=login" title="My Account">My Account</a>
    </div>
    <nav>
        <?php echo getNavList(); ?>
    </nav>
</header>

<?php

echo '<h2>Add Classification</h2>
        <form method="POST" action="../vehicles/vehicleController.php?action=classification">
            <label for="classificationName">Classification Name: </label>
            <input type="text" name="classificationName" id="classificationName" required>
            <br>
            <button type="submit">Add Classification</button>
        </form>';

        if (isset($message)) {
            echo $message;
        }
?>

<footer>
    <p>&copy; PHP Motors, All rights reserved.</p>
    <p>All Images are believed to be in "Fair Use". Please notify the author if any are not &amp; they will be removed.</p>
    <p>Last updated Jan. 2022</p>
</footer>

</div>