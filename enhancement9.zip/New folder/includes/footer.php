<footer>
    <p>&copy; PHP Motors, All rights reserved.</p>
    <p>All Images are believed to be in "Fair Use". Please notify the author if any are not &amp; they will be removed.</p>
    <p>Last updated Jan. 2022</p>
</footer>