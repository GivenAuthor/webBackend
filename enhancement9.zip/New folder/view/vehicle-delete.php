<?php
session_start();
include_once($_SERVER['DOCUMENT_ROOT'] .'../model/vehiclesModel.php');
include_once($_SERVER['DOCUMENT_ROOT'] .'./library/connections.php');
include_once($_SERVER['DOCUMENT_ROOT'] .'./model/mainModel.php');
if ($_SESSION['clientData']['clientLevel'] < 2 && $_SESSION['loggedin'] != true) {
    header('location: ../index.php');
    exit;
   }
if (isset($_SESSION['message'])) {
    $message = $_SESSION['message'];
}
?>

<div class="content-wrapper">
<head>
<link rel="stylesheet" media="screen" href="../css/template.css"/>
    <link rel="stylesheet" media="screen" href="../css/header.css"/>
    <link rel="stylesheet" media="screen" href="../css/home.css"/>
    <link rel="stylesheet" media="screen" href="../css/footer.css"/>
    <meta name="viewport" content="width=700, initial-scale=1">
    </head>
<header>
    <div class="top-banner">
    
    <title><?php if(isset($invInfo['invMake']) && isset($invInfo['invModel'])){ 
	 echo "Delete $invInfo[invMake] $invInfo[invModel]";} 
	elseif(isset($invMake) && isset($invModel)) { 
		echo "Delete $invMake $invModel"; }?> | PHP Motors</title>
     
        <img src="../images/site/logo.png" alt="Technically this shouldn't need an alt since it's purely decorative">
        <!-- <a href="./view/login.php" title="My Account">My Account</a> -->
        <?php
        if(isset($_SESSION['clientData']['clientFirstname'])){ echo "<p>Welcome <a href='../accounts/index.php?action=admin'>"; echo $_SESSION['clientData']['clientFirstname']; echo "</a></p>"; } 
        if ($_SESSION['loggedin'] == false) {echo '<a href="../accounts/index.php?action=login" title=" My Account">My Account</a>';}
        else {echo '<a href="../accounts/index.php?action=logout">Logout</a>';}
        ?>    </div>
    <nav>
        <?php echo $navList; ?>
    </nav>
</header>


    <h1><?php if(isset($invInfo['invMake']) && isset($invInfo['invModel'])){ 
	echo "Delete $invInfo[invMake] $invInfo[invModel]";} 
elseif(isset($invMake) && isset($invModel)) { 
	echo "Delete $invMake $invModel"; }?></h1>


<h2>Delete Vehicle</h2>
        <form method="post" action="../vehicles/index.php">
<fieldset>
	<label for="invMake">Vehicle Make</label>
	<input type="text" readonly name="invMake" id="invMake" <?php
if(isset($invInfo['invMake'])) {echo "value='$invInfo[invMake]'"; }?>>

	<label for="invModel">Vehicle Model</label>
	<input type="text" readonly name="invModel" id="invModel" <?php
if(isset($invInfo['invModel'])) {echo "value='$invInfo[invModel]'"; }?>>

	<label for="invDescription">Vehicle Description</label>
	<textarea name="invDescription" readonly id="invDescription"><?php
if(isset($invInfo['invDescription'])) {echo $invInfo['invDescription']; }
?></textarea>

<input type="submit" class="regbtn" name="submit" value="Delete Vehicle">

	<input type="hidden" name="action" value="deleteVehicle">
	<input type="hidden" name="invId" value="<?php if(isset($invInfo['invId'])){
echo $invInfo['invId'];} ?>">

</fieldset>
</form>
<?php
if (isset($message)) {
    echo $message;
}

?>

<footer>
    <p>&copy; PHP Motors, All rights reserved.</p>
    <p>All Images are believed to be in "Fair Use". Please notify the author if any are not &amp; they will be removed.</p>
    <p>Last updated Jan. 2022</p>
</footer>

</div>
<?php unset($_SESSION['message']); ?>