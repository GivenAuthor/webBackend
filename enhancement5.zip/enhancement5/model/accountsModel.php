<?php
include_once($_SERVER['DOCUMENT_ROOT'] . './library/connections.php');

function authenticateUser($clientEmail, $clientPassword) {
    $db = dbConnect();
    $sql = 'SELECT clientEmail FROM clients
                WHERE clientEmail = :clientEmail
                AND clientPassword = :clientPassword;';
    $stmt = $db->prepare($sql);
    $stmt->bindValue(':clientEmail', $_POST['email'], PDO::PARAM_STR);
    $stmt->bindValue(':clientPassword', $_POST['password'], PDO::PARAM_STR);
    $stmt->execute();
    $clientEmail = $stmt->fetch();
    $stmt->closeCursor();

    return $clientEmail;
}

function regClient($clientFirstname, $clientLastname, $clientEmail, $clientPassword) {
    $db = dbConnect();
    $sql = 'INSERT INTO clients (clientFirstname, clientLastname,clientEmail, clientPassword)
        VALUES (:clientFirstname, :clientLastname, :clientEmail, :clientPassword)';
    $stmt = $db->prepare($sql);
    $stmt->bindValue(':clientFirstname', $clientFirstname, PDO::PARAM_STR);
    $stmt->bindValue(':clientLastname', $clientLastname, PDO::PARAM_STR);
    $stmt->bindValue(':clientEmail', $clientEmail, PDO::PARAM_STR);
    $stmt->bindValue(':clientPassword', $clientPassword, PDO::PARAM_STR);
    $stmt->execute();
    $rowsChanged = $stmt->rowCount();
    $stmt->closeCursor();
    
    return $rowsChanged;
   }

?>