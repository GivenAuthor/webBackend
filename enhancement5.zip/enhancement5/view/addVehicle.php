<?php
include_once($_SERVER['DOCUMENT_ROOT'] .'../model/vehiclesModel.php');
include_once($_SERVER['DOCUMENT_ROOT'] .'./library/connections.php');
include_once($_SERVER['DOCUMENT_ROOT'] .'./model/mainModel.php');
?>

<div class="content-wrapper">
<head>
<link rel="stylesheet" media="screen" href="../css/template.css"/>
    <link rel="stylesheet" media="screen" href="../css/header.css"/>
    <link rel="stylesheet" media="screen" href="../css/home.css"/>
    <link rel="stylesheet" media="screen" href="../css/footer.css"/>
    <meta name="viewport" content="width=700, initial-scale=1">
    </head>
<header>
    <div class="top-banner">
        <img src="../images/site/logo.png" alt="Technically this shouldn't need an alt since it's purely decorative">
        <!-- <a href="./view/login.php" title="My Account">My Account</a> -->
        <a href="../controllers/accountController.php?action=login" title="My Account">My Account</a>
    </div>
    <nav>
        <?php echo $navList; ?>
    </nav>
</header>

<h2>Add Vehicle</h2>
        <form method="POST" action="../vehicles/vehicleController.php?action=vehicle">
            <label for="invMake">Make: </label>
            <input type="text" name="invMake" required <?php if(isset($invMake)){echo "value='$invMake'";} ?>>
            <br>
            <label for="invModel">Model: </label>
            <input type="text" name="invModel" required <?php if(isset($invModel)){echo "value='$invModel'";} ?>>
            <br>
            <label for="invDescription">Description: </label>
            <input type="text" name="invDescription" required <?php if(isset($invDescription)){echo "value='$invDescription'";} ?>>
            <br>
            <label for="invImage">Image: </label>
            <input type="text" name="invImage" required <?php if(isset($invImage)){echo "value='$invImage'";} ?>>
            <br>
            <label for="invThumbnail">Thumbnail: </label>
            <input type="text" name="invThumbnail" required <?php if(isset($invThumbnail)){echo "value='$invThumbnail'";} ?>>
            <br>
            <label for="invPrice">Price: </label>
            <input type="number" name="invPrice" required <?php if(isset($invPrice)){echo "value='$invPrice'";} ?>>
            <br>
            <label for="invStock">Stock: </label>
            <input type="number" name="invStock" required <?php if(isset($invStock)){echo "value='$invStock'";} ?>>
            <br>
            <label for="invColor">Color: </label>
            <input type="text" name="invColor" required <?php if(isset($invColor)){echo "value='$invColor'";} ?>>
            <br>
            <label for="classificationId">Classification: </label>
            <?php
            displayClassifications();
            ?>
            <br>
            <button type="submit">Add Vehicle</button>
        </form>
<?php
if (isset($message)) {
    echo $message;
}

?>

<footer>
    <p>&copy; PHP Motors, All rights reserved.</p>
    <p>All Images are believed to be in "Fair Use". Please notify the author if any are not &amp; they will be removed.</p>
    <p>Last updated Jan. 2022</p>
</footer>

</div>