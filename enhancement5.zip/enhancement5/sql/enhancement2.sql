
insert into clients(clientFirstName, clientLastName, clientEmail, clientPassword, comment)
values('Tony', 'Stark', 'tony@starkent.com', 'Iam1ronM@n', 'I am the real Ironman');

update clients 
set clientLevel = 3 
where clientEmail = 'tony@starkent.com';


delete from inventory
where invModel = 'Wrangler';

UPDATE inventory
SET invImage = CONCAT('/phpmotors', invImage ),
invThumbnail = CONCAT('/phpmotors', invThumbnail );

--
--
--

select
replace('small interior', 'small interior', 'spacious interior');

select i.invModel, c.classificationName
from inventory i
inner join carclassification c
on c.classificationName = i.invMake;

select * from inventory;
select * from clients;
