<?php
include_once($_SERVER['DOCUMENT_ROOT'] . './model/accountsModel.php');
include_once($_SERVER['DOCUMENT_ROOT'] . './library/connections.php');
include_once($_SERVER['DOCUMENT_ROOT'] . './library/functions.php');
require_once($_SERVER['DOCUMENT_ROOT'] .'./model/mainModel.php');

$classifications = getClassifications();
$navList = getNavList($classifications);

    $action = filter_input(INPUT_POST, 'action');
        if ($action == NULL) {
    $action = filter_input(INPUT_GET, 'action');
        }
    switch ($action) {
        case 'login':
            $clientEmail = trim(filter_input(INPUT_POST, 'clientEmail', FILTER_SANITIZE_EMAIL));
            $clientPassword = trim(filter_input(INPUT_POST, 'clientPassword', FILTER_SANITIZE_EMAIL));
            
            $clientEmail = checkEmail($clientEmail);
            $checkPassword = checkPassword($clientPassword);

            if(empty($clientEmail) || empty($checkPassword)){
                $message = '<p>Please provide information for all empty form fields.</p>';
                include $_SERVER['DOCUMENT_ROOT'] .'./view/login.php';
                exit; 
               }

            // Send the data to the model
            $regOutcome = authenticateUser($clientEmail, $clientPassword);
            
            if($regOutcome === 1){
                include $_SERVER['DOCUMENT_ROOT'] .'./view/home.php';
                exit;
               } else {
                $message = "<p>Sorry but the login failed. Please try again.</p>";
                include $_SERVER['DOCUMENT_ROOT'] . './view/login.php';
                exit;
               }
            
        break;
        case 'register':
            $clientFirstname = trim(filter_input(INPUT_POST, 'clientFirstname', FILTER_SANITIZE_STRING));
            $clientLastname = trim(filter_input(INPUT_POST, 'clientLastname', FILTER_SANITIZE_STRING));
            $clientEmail = trim(filter_input(INPUT_POST, 'clientEmail', FILTER_SANITIZE_EMAIL));
            $clientPassword = trim(filter_input(INPUT_POST, 'clientPassword', FILTER_SANITIZE_EMAIL));
            
            $clientEmail = checkEmail($clientEmail);
            $checkPassword = checkPassword($clientPassword);

            if(empty($clientFirstname) || empty($clientLastname) || empty($clientEmail) || empty($checkPassword)){
                $message = '<p>Please provide information for all empty form fields.</p>';
                include $_SERVER['DOCUMENT_ROOT'] .'./view/register.php';
                exit; 
               }

            // Send the data to the model
            $regOutcome = regClient($clientFirstname, $clientLastname, $clientEmail, $clientPassword);
            
            if($regOutcome === 1){
                $message = "<p>Thanks for registering $clientFirstname. Please use your email and password to login.</p>";
                include $_SERVER['DOCUMENT_ROOT'] .'./view/login.php';
                exit;
               } else {
                $message = "<p>Sorry $clientFirstname, but the registration failed. Please try again.</p>";
                include $_SERVER['DOCUMENT_ROOT'] . './view/register.php';
                exit;
               }

        break;
        default:
            include $_SERVER['DOCUMENT_ROOT'] .'./view/home.php';
       }

?>