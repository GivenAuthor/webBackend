<?php

function addReview($reviewText, $invId, $clientId) {
    $db = dbConnect();
    $sql = 'INSERT INTO reviews(reviewText,invId,clientId) VALUES (:reviewText, :invId, :clientId)';
    $stmt = $db->prepare($sql);
    $stmt->bindValue(':reviewText', $reviewText, PDO::PARAM_STR);
    $stmt->bindValue(':invId', $invId, PDO::PARAM_STR);
    $stmt->bindValue(':clientId', $clientId, PDO::PARAM_STR);
    $stmt->execute();
    $rowsChanged = $stmt->rowCount();
    $stmt->closeCursor();
    return $rowsChanged;
}

function updateReview($reviewText, $invId, $clientId) {
    $db = dbConnect();
    $sql = 'UPDATE reviews set reviewText = :reviewText WHERE invId = :invId AND clientId = :clientId';
    $stmt = $db->prepare($sql);
    $stmt->bindValue(':reviewText', $reviewText, PDO::PARAM_STR);
    $stmt->bindValue(':invId', $invId, PDO::PARAM_STR);
    $stmt->bindValue(':clientId', $clientId, PDO::PARAM_STR);
    $stmt->execute();
    $rowsChanged = $stmt->rowCount();
    $stmt->closeCursor();
    return $rowsChanged;
}

function deleteReview($reviewText, $invId, $clientId) {
    $db = dbConnect();
    $sql = 'DELETE FROM reviews WHERE reviewText = :reviewText AND invId = :invId AND clientId = :clientId';
    $stmt = $db->prepare($sql);
    $stmt->bindValue(':reviewText', $reviewText, PDO::PARAM_STR);
    $stmt->bindValue(':invId', $invId, PDO::PARAM_STR);
    $stmt->bindValue(':clientId', $clientId, PDO::PARAM_STR);
    $stmt->execute();
    $rowsChanged = $stmt->rowCount();
    $stmt->closeCursor();
    return $rowsChanged;
}

function getReviewsByInvId($invId) {
    $db = dbConnect();
    $sql = 'SELECT * FROM reviews 
	    INNER JOIN clients on reviews.clientId = clients.clientId
        WHERE reviews.invId = :invId
        ORDER BY reviews.reviewDate DESC'; 
    $stmt = $db->prepare($sql); 
    $stmt->bindValue(':invId', $invId, PDO::PARAM_INT); 
    $stmt->execute(); 
    $reviews = $stmt->fetchAll(PDO::FETCH_ASSOC); 
    $stmt->closeCursor(); 
    return $reviews; 
}

function getReviewsByClientId($clientId) {
    $db = dbConnect(); 
    $sql = 'SELECT * FROM reviews 
	    INNER JOIN clients on reviews.clientId = clients.clientId
        WHERE reviews.clientId = :clientId
        ORDER BY reviews.reviewDate DESC'; 
    $stmt = $db->prepare($sql); 
    $stmt->bindValue(':clientId', $clientId, PDO::PARAM_INT); 
    $stmt->execute(); 
    $reviews = $stmt->fetchAll(PDO::FETCH_ASSOC); 
    $stmt->closeCursor(); 
    return $reviews; 
}

function getSpecificReview($reviewText, $invId, $clientId) {
    $db = dbConnect();
    $sql = 'SELECT * FROM reviews 
	    INNER JOIN clients on reviews.clientId = clients.clientId
        WHERE reviews.clientId = :clientId
        AND reviewText = :reviewText
        AND invId = :invId'; 
    $stmt = $db->prepare($sql); 
    $stmt->bindValue(':clientId', $clientId, PDO::PARAM_INT);
    $stmt->bindValue(':reviewText', $reviewText, PDO::PARAM_STR);
    $stmt->bindValue(':invId', $invId, PDO::PARAM_STR); 
    $stmt->execute(); 
    $reviews = $stmt->fetchAll(PDO::FETCH_ASSOC); 
    $stmt->closeCursor(); 
    return $reviews; 
}

?>