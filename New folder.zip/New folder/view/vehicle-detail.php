<?php
if ($_SESSION['clientData']['clientLevel'] < 2 && $_SESSION['loggedin'] != true) {
    header('location: ../index.php');
    exit;
   }
?>
<head>
<link rel="stylesheet" media="screen" href="../css/template.css"/>
    <link rel="stylesheet" media="screen" href="../css/header.css"/>
    <link rel="stylesheet" media="screen" href="../css/home.css"/>
    <link rel="stylesheet" media="screen" href="../css/footer.css"/>
    <link rel="stylesheet" media="screen" href="../css/vehicles.css"/>
    <meta name="viewport" content="width=700, initial-scale=1">
    </head>
<div class="content-wrapper">
<header>
    <div class="top-banner">
        <img src="../images/site/logo.png" alt="Technically this shouldn't need an alt since it's purely decorative">
        <!-- <a href="./view/login.php" title="My Account">My Account</a> -->
        <?php
        if(isset($_SESSION['clientData']['clientFirstname'])){ echo "<p>Welcome <a href='../accounts/index.php?action=admin'>"; echo $_SESSION['clientData']['clientFirstname']; echo "</a></p>"; } 
        if ($_SESSION['loggedin'] == false) {echo '<a href="../accounts/index.php?action=login" title=" My Account">My Account</a>';}
        else {echo '<a href="../accounts/index.php?action=logout">Logout</a>';}
        ?>    </div>
    <nav>
        <?php echo $navList; ?>
    </nav>
</header>
<body>
<?php

if (isset($message)) {
    echo($message);
}

echo "<p>Reviews can be found at the bottom of the screen</p>";

echo $vehicleDetails;

if (isset($imageDisplay)) {
    echo $imageDisplay;
}

echo "<h2>Reviews</h2>";

if (isset($reviewMessage)) {
    echo $reviewMessage;
}

if ($_SESSION['loggedin'] != true) {
    echo "<p>You can add a review by logging in</p>";
}
else {
        echo '<form method="POST" action="../reviews/index.php?action=addReview&invId=' . $invId . '">
            <label for="reviewText">Enter your review here: </label>
            <input type="text" name="reviewtext">
            <br>
            <input type="hidden" name="invId">
            <input type="hidden" name="clientId">
            <input type="hidden" name="action" value="addReview">
            <input type="submit" name="submit" value="Add Review">
            </form>';
}

if (isset($reviews)) {
    echo $reviews;
}
else {
    echo "<p>There are currently no reviews for this vehicle</p>";
}

?>

<footer>
    <p>&copy; PHP Motors, All rights reserved.</p>
    <p>All Images are believed to be in "Fair Use". Please notify the author if any are not &amp; they will be removed.</p>
    <p>Last updated Jan. 2022</p>
</footer>
</div>