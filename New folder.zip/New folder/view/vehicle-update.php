<?php
session_start();
include_once($_SERVER['DOCUMENT_ROOT'] .'../model/vehiclesModel.php');
include_once($_SERVER['DOCUMENT_ROOT'] .'./library/connections.php');
include_once($_SERVER['DOCUMENT_ROOT'] .'./model/mainModel.php');
if ($_SESSION['clientData']['clientLevel'] < 2 && $_SESSION['loggedin'] != true) {
    header('location: ../index.php');
    exit;
   }
if (isset($_SESSION['message'])) {
    $message = $_SESSION['message'];
}
?>

<div class="content-wrapper">
<head>
<link rel="stylesheet" media="screen" href="../css/template.css"/>
    <link rel="stylesheet" media="screen" href="../css/header.css"/>
    <link rel="stylesheet" media="screen" href="../css/home.css"/>
    <link rel="stylesheet" media="screen" href="../css/footer.css"/>
    <meta name="viewport" content="width=700, initial-scale=1">
    </head>
<header>
    <div class="top-banner">
    <title><?php if(isset($invInfo['invMake']) && isset($invInfo['invModel'])){ 
	 echo "Modify $invInfo[invMake] $invInfo[invModel]";} 
	elseif(isset($invMake) && isset($invModel)) { 
		echo "Modify $invMake $invModel"; }?> | PHP Motors</title>

        <img src="../images/site/logo.png" alt="Technically this shouldn't need an alt since it's purely decorative">
        <!-- <a href="./view/login.php" title="My Account">My Account</a> -->
        <?php
        if(isset($_SESSION['clientData']['clientFirstname'])){ echo "<p>Welcome <a href='../accounts/index.php?action=admin'>"; echo $_SESSION['clientData']['clientFirstname']; echo "</a></p>"; } 
        if ($_SESSION['loggedin'] == false) {echo '<a href="../accounts/index.php?action=login" title=" My Account">My Account</a>';}
        else {echo '<a href="../accounts/index.php?action=logout">Logout</a>';}
        ?>    </div>
    <nav>
        <?php echo $navList; ?>
    </nav>
</header>


    <h1><?php if(isset($invInfo['invMake']) && isset($invInfo['invModel'])){ 
	echo "Modify $invInfo[invMake] $invInfo[invModel]";} 
elseif(isset($invMake) && isset($invModel)) { 
	echo "Modify$invMake $invModel"; }?>


<h2>Update Vehicle</h2>
        <form method="POST" action="">
            <label for="invMake">Make: </label>
             <input type="text" name="invMake" id="invMake" required <?php if(isset($invMake)){ echo "value='$invMake'"; } elseif(isset($invInfo['invMake'])) {echo "value='$invInfo[invMake]'"; }?>>
 
            <br>
            <label for="invModel">Model: </label>
            <input type="text" name="invModel" id="invModel" required <?php if(isset($invModel)){ echo "value='$invModel'"; } elseif(isset($invInfo['invModel'])) {echo "value='$invInfo[invModel]'"; }?>>

            <br>
            <label for="invDescription">Description: </label>
            <input type="text" name="invDescription" id="invDescription" required <?php if(isset($invDescription)){ echo "value='$invDescription'"; } elseif(isset($invInfo['invDescription'])) {echo "value='$invInfo[invDescription]'"; }?>>
            <br>
            <label for="invImage">Image: </label>
            <input type="text" name="invImage" id="invImage" required <?php if(isset($invImage)){ echo "value='$invImage'"; } elseif(isset($invInfo['invImage'])) {echo "value='$invInfo[invImage]'"; }?>>
 
            <br>
            <label for="invThumbnail">Thumbnail: </label>
            <input type="text" name="invThumbnail" id="invThumbnail" required <?php if(isset($invThumbnail)){ echo "value='$invThumbnail'"; } elseif(isset($invInfo['invThumbnail'])) {echo "value='$invInfo[invThumbnail]'"; }?>>
 
            <br>
            <label for="invPrice">Price: </label>
            <input type="text" name="invPrice" id="invPrice" required <?php if(isset($invPrice)){ echo "value='$invPrice'"; } elseif(isset($invInfo['invPrice'])) {echo "value='$invInfo[invPrice]'"; }?>>

            <br>
            <label for="invStock">Stock: </label>
            <input type="text" name="invStock" id="invStock" required <?php if(isset($invStock)){ echo "value='$invStock'"; } elseif(isset($invInfo['invStock'])) {echo "value='$invInfo[invStock]'"; }?>>

            <br>
            <label for="invColor">Color: </label>
            <input type="text" name="invColor" id="invColor" required <?php if(isset($invColor)){ echo "value='$invColor'"; } elseif(isset($invInfo['invColor'])) {echo "value='$invInfo[invColor]'"; }?>>
            <br>
            <label for="classificationId">Classification: </label>
            <?php
            echo buildClassifications();
            ?>
            <br>
            <input type="hidden" name="action" value="updateVehicle">
            <input type="submit" name="submit" value="Update Vehicle">

            <input type="hidden" name="invId" value="
            <?php if(isset($invInfo['invId'])){ echo $invInfo['invId'];} 
            elseif(isset($invId)){ echo $invId; } ?>
            ">

        </form>
<?php
if (isset($message)) {
    echo $message;
}

?>

<footer>
    <p>&copy; PHP Motors, All rights reserved.</p>
    <p>All Images are believed to be in "Fair Use". Please notify the author if any are not &amp; they will be removed.</p>
    <p>Last updated Jan. 2022</p>
</footer>

</div>
<?php unset($_SESSION['message']); ?>