<?php
if ($_SESSION['loggedin'] == false) {
    header('Location: ../index.php');
}
?><!DOCTYPE html>

<html>
<div class="content-wrapper">
<head>
<link rel="stylesheet" media="screen" href="../css/template.css"/>
    <link rel="stylesheet" media="screen" href="../css/header.css"/>
    <link rel="stylesheet" media="screen" href="../css/home.css"/>
    <link rel="stylesheet" media="screen" href="../css/footer.css"/>
    <meta name="viewport" content="width=700, initial-scale=1">
    </head>
<div class="content-wrapper">
<header>
    <div class="top-banner">
        <img src="../images/site/logo.png" alt="Technically this shouldn't need an alt since it's purely decorative">
        <!-- <a href=".//login.php" title="My Account">My Account</a> -->
        <?php
        if(isset($_SESSION['clientData']['clientFirstname'])){ echo "<p>Welcome <a href='../accounts/index.php?action=admin'>"; echo $_SESSION['clientData']['clientFirstname']; echo "</a></p>"; } 
        if ($_SESSION['loggedin'] == false) {echo '<a href="../accounts/index.php?action=login" title=" My Account">My Account</a>';}
        else {echo '<a href="../accounts/index.php?action=logout">Logout</a>';}
        ?>
    </div>
    <nav>
        <?php echo $navList; ?>
    </nav>
</header>

<body>
<div class="content-wrapper">

<h1>
<?php echo ("hello  " . $_SESSION['clientData']['clientFirstname']) . " you are logged in"; ?>
</h1>
<br>
<p>
    <a href="../accounts/index.php?action=modifyAccount">Update Account Information</a>
</p>

<ul>
<!-- don't display these
    <li>First Name: <?php echo $_SESSION['clientData']['clientFirstname']; ?></li>
    <li>Last Name: <?php echo $_SESSION['clientData']['clientLastname']; ?></li>
    <li>Email: <?php echo $_SESSION['clientData']['clientEmail']; ?></li>
    -->
</ul>

<?php

if ($_SESSION['clientData']['clientLevel'] > 1) {
    echo ('<h4>This link should be used to manage inventory</h4>');
    echo '<p><a href="../vehicles/index.php">Vehicles</a></p>';
}

if (isset($confirmation)) {
    echo $confirmation;
}

if (isset($reviews)) {
    echo $reviews;
}
else {
    echo "<p>You have not left any reviews</p>";
}
if (isset($reviewMessage)) {
    echo $reviewMessage;
}

?>

</body>

<footer>
    <p>&copy; PHP Motors, All rights reserved.</p>
    <p>All Images are believed to be in "Fair Use". Please notify the author if any are not &amp; they will be removed.</p>
    <p>Last updated Jan. 2022</p>
</footer>
</div>
</html>