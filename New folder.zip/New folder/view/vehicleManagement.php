<?php
session_start();
include_once ($_SERVER['DOCUMENT_ROOT'] .'./vehicles/index.php');
include_once($_SERVER['DOCUMENT_ROOT'] .'./library/connections.php');
include_once($_SERVER['DOCUMENT_ROOT'] .'./model/mainModel.php');
// include_once($_SERVER['DOCUMENT_ROOT'] .'./js/inventory.js');
if ($_SESSION['clientData']['clientLevel'] < 2 && $_SESSION['loggedin'] != true) {
    header('location: ../index.php');
    exit;
   }
?>
<head>
<link rel="stylesheet" media="screen" href="../css/template.css"/>
    <link rel="stylesheet" media="screen" href="../css/header.css"/>
    <link rel="stylesheet" media="screen" href="../css/home.css"/>
    <link rel="stylesheet" media="screen" href="../css/footer.css"/>
    <meta name="viewport" content="width=700, initial-scale=1">
    </head>
<div class="content-wrapper">
<header>
    <div class="top-banner">
        <img src="../images/site/logo.png" alt="Technically this shouldn't need an alt since it's purely decorative">
        <!-- <a href="./view/login.php" title="My Account">My Account</a> -->
        <?php
        if(isset($_SESSION['clientData']['clientFirstname'])){ echo "<p>Welcome <a href='../accounts/index.php?action=admin'>"; echo $_SESSION['clientData']['clientFirstname']; echo "</a></p>"; } 
        if ($_SESSION['loggedin'] == false) {echo '<a href="../accounts/index.php?action=login" title=" My Account">My Account</a>';}
        else {echo '<a href="../accounts/index.php?action=logout">Logout</a>';}
        ?>    </div>
    <nav>
        <?php echo $navList; ?>
    </nav>
</header>
<body>
<?php
if (isset($message)) { 
    echo $message; 
   }
echo '  <br>
        <a href="../vehicles/index.php?action=addClassification">Add Classification</a>
        <br>
        <a href="../vehicles/index.php?action=vehicle">Add Vehicle</a>';

if (isset($classificationList)) { 
    echo '<h2>Vehicles By Classification</h2>'; 
    echo '<p>Choose a classification to see those vehicles</p>'; 
    echo $classificationList;
    
}
?>

<noscript>
<p><strong>JavaScript Must Be Enabled to Use this Page.</strong></p>
</noscript>

    <table id="inventoryDisplay"></table> 
    
</body>
    <script src="../js/inventory.js"></script> 
<footer>
    <p>&copy; PHP Motors, All rights reserved.</p>
    <p>All Images are believed to be in "Fair Use". Please notify the author if any are not &amp; they will be removed.</p>
    <p>Last updated Jan. 2022</p>
</footer>
</div>