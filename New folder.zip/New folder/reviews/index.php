<?php
session_start();
include_once($_SERVER['DOCUMENT_ROOT'] .'./model/mainModel.php');
include_once($_SERVER['DOCUMENT_ROOT'] . './library/functions.php');
include_once($_SERVER['DOCUMENT_ROOT'] . './model/reviewsModel.php');

$classificationsnav = getClassifications();
$navList = getNavList($classificationsnav);

function buildClassifications() {
    $classifications = getClassificationsWithId();
    $toDisplay = '<select name="classificationId">';

    foreach ($classifications as $classification) {
        $toDisplay .= '<option value="'. $classification["classificationId"] .'">' . $classification["classificationName"] . '</option>';
      }
    $toDisplay .= '</select>';

      $classifList = '<select name="classificationId" id="classificationId">';
      $classifList .= "<option>Choose a Car Classification</option>";
      foreach ($classifications as $classification) {
          $classifList .= "<option value='$classification[classificationId]'";
          if(isset($classificationId)){
              if($classification['classificationId'] === $classificationId){
                  $classifList .= ' selected ';
                }
            } elseif(isset($invInfo['classificationId'])){
                if($classification['classificationId'] === $invInfo['classificationId']){
                    $classifList .= ' selected ';
                }
            }
            $classifList .= ">$classification[classificationName]</option>";
        }
        $classifList .= '</select>';
        return $classifList;
    
}

$action = filter_input(INPUT_POST, 'action');
        if ($action == NULL) {
    $action = filter_input(INPUT_GET, 'action');
}

switch($action) {
    case 'addReview':
        // get review text, inventory id, and client id
        $reviewText = trim(filter_input(INPUT_POST, 'reviewtext', FILTER_SANITIZE_STRING));
        $invId = filter_input(INPUT_GET, 'invId', FILTER_VALIDATE_INT);
        // This needs to be grabbed when the user logs in
        $clientId = $_SESSION['clientId'];

        if (empty($reviewText)) {
            $reviewMessage = 'Please enter a review';
            header('location: ../vehicles/index.php?action=vehicleDetails&invId=' . $invId);
            exit;
        }

        if (empty($clientId)) {
            $reviewMessage = 'Please log in to leave a review';
            header('location: ../vehicles/index.php?action=vehicleDetails&invId=' . $invId);
            exit;
        }

        $result = addReview($reviewText, $invId, $clientId);

        if (!empty($result)) {
            $reviewMessage = 'There was an error adding your review';
            header('location: ../vehicles/index.php?action=vehicleDetails&invId=' . $invId);
            exit;
        }
        $reviewMessage = 'Review added successfully';
        header('location: ../vehicles/index.php?action=vehicleDetails&invId=' . $invId);
        break;
    case 'updateView':
        // deliver a view to edit the review
        include '../view/editReview.php';
        break;
    case 'updateReview':
        $reviewText = trim(filter_input(INPUT_POST, 'reviewText', FILTER_SANITIZE_STRING));
        $invId = filter_input(INPUT_POST, 'invId', FILTER_SANITIZE_STRING);
        $clientId = $_SESSION['clientId'];

        $result = updateReview($reviewText, $invId, $clientId);

        if (empty($result)) {
            $reviewMessage = 'There was an error updating your review';
            include '../view/admin.php'; 
            exit;
        }
        else {
            $reviewMessage = 'review updated successfully';
        }

        $reviewsArray = getReviewsByClientId($clientId);
        $reviews = buildReviewDisplayEditable($reviewsArray);
        include '../view/admin.php';

        break;
    case 'checkDelete':
        $reviewText2 = trim(filter_input(INPUT_POST, 'reviewText2', FILTER_SANITIZE_STRING));
        $invId2 = filter_input(INPUT_POST, 'invId2', FILTER_SANITIZE_STRING);
        $clientId2 = $_SESSION['clientId'];
        $confirmReview = getSpecificReview($reviewText2, $invId2, $clientId2);

        $confirmation = displayReviewForDeleteConfirmation($confirmReview);
        include '../view/admin.php';

        break;
    case 'deleteReview':
        $reviewText3 = trim(filter_input(INPUT_POST, 'reviewText3', FILTER_SANITIZE_STRING));
        $invId3 = filter_input(INPUT_POST, 'invId2', FILTER_VALIDATE_INT);
        $clientId3 = $_SESSION['clientId'];

        $deleteResult = deleteReview($reviewText3, $invId3, $clientId3);
        $reviewMessage = 'review deleted successfully';

        $reviewsArray = getReviewsByClientId($_SESSION['clientId']);
        $reviews = displayReviewForDeleteConfirmation($reviewsArray);
        include '../view/admin.php';

        break;
    default:
        include '../view/admin.php';
        break;


}

?>