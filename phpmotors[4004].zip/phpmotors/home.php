<main>
    <h1>Welcome to PHP Motors!</h1>
    <aside class="product-info">
        <!-- While I could superimpose the description over the product image, that strikes me as a HORRIBLE idea (responsive design, right?). So that's not gonna happen -->
        <div class="description">
            <h2>DMC Delorean</h2>
            <p>3 Cup Holders</p>
            <p>Superman Doors</p>
            <p>Fuzzy Dice!</p>
            <!-- This should NOT be an img... -->
            <button class="purchase desktop">Own Today</button>
        </div>
        <img class="vehicle-img" src="images/delorean.jpg" alt="A 1982 time-traveling DMC Delorean. Plutonium & cotton underwear not included.">
        <!-- This should NOT be an img... -->
        <button class="purchase mobile">Own Today</button>
    </aside>

    <aside class="product-details">
        <div class="product-reviews">
            <h2>DMC Delorean Reviews</h2>
            <ul>
                <li>"The stainless steel construction makes the flux dispersal — look out!!!" (5/5)</li>
                <li>"So Fast, it's almost like traveling in time." (4/5)</li>
                <li>"Coolest ride on the road." (4/5)</li>
                <li>"The alt text on the product image made it sound like it came with a flux capacitor already." (1/5)</li>
            </ul>
        </div>

        <div class="product-upgrades">
            <h2>Delorean Upgrades</h2>
            <div class="upgrade-flex-container">
                <div class="upgrade-wrapper">
                    <div class="upgrade-img-wrapper">
                        <img alt="The Flux Capacitor" src="images/upgrades/flux-cap.png">
                    </div>
                    <a title="Flux Capacitor">Flux Capacitor</a>
                </div>
                <div class="upgrade-wrapper">
                    <div class="upgrade-img-wrapper">
                        <img alt="Flame Decals" src="images/upgrades/flame.png">
                    </div>
                    <a title="Flame Decals">Flame Decals</a>
                </div>
                <div class="upgrade-wrapper">
                    <div class="upgrade-img-wrapper">
                        <img alt="Bumper Stickers" src="images/upgrades/bumper_sticker.jpg">
                    </div>
                    <a title="Bumper Stickers">Bumper Stickers</a>
                </div>
                <div class="upgrade-wrapper">
                    <div class="upgrade-img-wrapper">
                        <img alt="Hub Caps" src="images/upgrades/hub-cap.svg">
                    </div>
                    <a title="Hub Caps">Hub Caps</a>
                </div>
            </div>
        </div>
    </aside>
</main>
