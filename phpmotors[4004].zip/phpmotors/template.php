<!DOCTYPE html>

<html>
<head>
    <title>PHP Motors</title>
    <link rel="stylesheet" media="screen" href="../css/template.css"/>
    <link rel="stylesheet" media="screen" href="../css/header.css"/>
    <link rel="stylesheet" media="screen" href="../css/home.css"/>
    <link rel="stylesheet" media="screen" href="../css/footer.css"/>
    <meta name="viewport" content="width=700, initial-scale=1">
</head>
<body>
<div class="content-wrapper">
    <?php include "./header.php"?>
    <?php include "./home.php" ?>
    <?php include "./footer.php"?>
</div>
</body>

</html>
