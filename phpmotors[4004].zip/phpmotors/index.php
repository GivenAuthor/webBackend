<?php
include "./template.php"
?>