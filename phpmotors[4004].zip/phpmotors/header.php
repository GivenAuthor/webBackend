<header>
    <div class="top-banner">
        <img src="../images/site/logo.png" alt="Technically this shouldn't need an alt since it's purely decorative">
        <a title="My Account">My Account</a>
    </div>
    <nav>
        <a title="Home">Home</a>
        <a title="Classic">Classic</a>
        <a title="Sports">Sports</a>
        <a title="SUV's">SUV's</a>
        <a title="Trucks">Trucks</a>
        <a title="Used">Used</a>
    </nav>
</header>